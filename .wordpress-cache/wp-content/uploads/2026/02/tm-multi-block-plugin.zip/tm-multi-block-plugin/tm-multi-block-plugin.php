<?php

/**
 * Plugin Name: TM Multi-Block Plugin
 * Description: A plugin with multiple Gutenberg blocks.
 * Version: 1.0.0
 * Author: THATMUCH
 */

function my_plugin_register_blocks()
{
	register_block_type(__DIR__ . '/build/blocks/faq');
	register_block_type(__DIR__ . '/build/blocks/features');
	register_block_type(__DIR__ . '/build/blocks/blog');
	register_block_type(__DIR__ . '/build/blocks/toc');
}
add_action('init', 'my_plugin_register_blocks');
