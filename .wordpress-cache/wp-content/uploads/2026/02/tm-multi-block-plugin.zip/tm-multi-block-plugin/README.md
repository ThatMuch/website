# TM Multi-Block Plugin

Un plugin WordPress avancé offrant une collection de blocs Gutenberg interactifs et modernes, développé par **THATMUCH**.

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-6.0%2B-blue.svg)
![PHP](https://img.shields.io/badge/PHP-8.0%2B-purple.svg)
![React](https://img.shields.io/badge/React-18-61dafb.svg)

## 📋 Table des Matières

- [Aperçu](#aperçu)
- [Fonctionnalités](#fonctionnalités)
- [Blocs Inclus](#blocs-inclus)
- [Installation](#installation)
- [Utilisation](#utilisation)
- [Développement](#développement)
- [Structure du Projet](#structure-du-projet)
- [Tests](#tests)
- [Contribution](#contribution)
- [Support](#support)
- [Changelog](#changelog)
- [Licence](#licence)

## 🎯 Aperçu

Le **TM Multi-Block Plugin** est une solution complète qui enrichit l'éditeur Gutenberg de WordPress avec quatre blocs spécialisés et entièrement interactifs. Chaque bloc utilise React côté front-end pour offrir une expérience utilisateur dynamique et moderne.

### ✨ Points Forts

- 🚀 **Blocs entièrement React** - Interactivité côté front-end
- 🎨 **Interface moderne** - Design responsive et accessible
- ⚙️ **Hautement configurable** - Paramètres avancés dans l'éditeur
- 🔧 **Architecture robuste** - Code modulaire et maintenable
- 📱 **100% Responsive** - Optimisé pour tous les écrans
- ♿ **Accessible** - Conforme aux standards WCAG

## 🚀 Fonctionnalités

### Fonctionnalités Générales

- ✅ **Compatible WordPress 6.0+**
- ✅ **Interface Gutenberg native**
- ✅ **Rendu React côté front-end**
- ✅ **Styles SCSS modulaires**
- ✅ **Configuration JSON flexible**
- ✅ **API REST WordPress intégrée**
- ✅ **Gestion d'erreurs avancée**
- ✅ **Support multilingue (i18n ready)**

### Fonctionnalités Techniques

- 🔧 **Build Webpack optimisé**
- 🎯 **Code splitting automatique**
- 📦 **Lazy loading des composants**
- 🔄 **Hot reloading en développement**
- 🧪 **Suite de tests automatisés**
- 📊 **Logging et debugging intégrés**

## 📦 Blocs Inclus

### 1. 📝 Blog Block (`tm-multi-block/blog`)

Un bloc dynamique pour afficher les articles récents avec une interface entièrement React.

**Fonctionnalités :**

- 📊 **Nombre d'articles configurable** (1-10)
- 📖 **Affichage conditionnel des extraits**
- 🖼️ **Images mises en avant automatiques**
- 🔄 **Chargement dynamique via API REST**
- 📱 **Layout responsive (grid)**
- ⚡ **Performance optimisée**

**Paramètres Éditeur :**

- Nombre d'articles à afficher
- Toggle pour afficher/masquer les extraits
- Aperçu en temps réel

**Rendu Front-end :**

- Récupération des posts via API WordPress
- Gestion des images mises en avant
- États de chargement et d'erreur
- Design moderne avec hover effects

### 2. ❓ FAQ Block (`tm-multi-block/faq`)

Un bloc accordéon interactif pour les questions fréquemment posées.

**Fonctionnalités :**

- 🔽 **Accordéon React interactif**
- ➕ **Ajout/suppression de Q&A**
- 🎨 **Interface d'édition intuitive**
- 📱 **Animation fluides**
- 🔧 **Personnalisation avancée**

**Paramètres Éditeur :**

- Ajout de questions/réponses illimité
- Réorganisation par drag & drop
- Prévisualisation en temps réel

**Rendu Front-end :**

- Accordéon entièrement fonctionnel
- Animations CSS3 fluides
- Gestion des états ouverts/fermés
- Persistance des configurations

### 3. ⭐ Features Block (`tm-multi-block/features`)

Un bloc de mise en avant des fonctionnalités avec support d'images.

**Fonctionnalités :**

- 🖼️ **Upload d'images via MediaUpload**
- 📝 **Titre et description personnalisables**
- 🎯 **Layout flexible**
- 🎨 **Styles modernes**
- 📱 **Design responsive**

**Paramètres Éditeur :**

- Sélection d'images depuis la médiathèque
- Édition de titre et description
- Gestion des attributs alt

**Rendu Front-end :**

- Affichage optimisé des images
- Textes formatés
- Responsive design
- Performance optimisée

### 4. 📑 Table of Contents Block (`tm-multi-block/toc`)

Un bloc intelligent qui génère automatiquement une table des matières basée sur les titres de la page.

**Fonctionnalités :**

- 🔍 **Détection automatique des titres** (H1-H6)
- ⚙️ **Sélection des niveaux à inclure**
- 🔗 **Génération d'ancres automatique**
- 📱 **Navigation avec défilement fluide**
- 🎛️ **Options d'affichage avancées**
- 🔄 **Mise à jour dynamique du contenu**

**Paramètres Éditeur :**

- Choix des niveaux de titres (H1, H2, H3, H4, H5, H6)
- Titre personnalisable de la table
- Option numérotation ou puces
- Mode pliable/dépliable
- Aperçu en temps réel

**Rendu Front-end :**

- Scan automatique des titres de la page
- Ajout d'ancres uniques à chaque titre
- Table des matières interactive
- Smooth scroll vers les sections
- Highlight temporaire des titres ciblés
- Observer les changements DOM dynamiques

## 🛠️ Installation

### Prérequis

- **WordPress** 6.0 ou supérieur
- **PHP** 8.0 ou supérieur
- **Node.js** 18+ (pour le développement)
- **Yarn** ou **npm** (pour le développement)

### Installation Standard

1. **Téléchargez** le plugin depuis le repository
2. **Extrayez** l'archive dans `/wp-content/plugins/`
3. **Activez** le plugin dans l'admin WordPress
4. **Utilisez** les nouveaux blocs dans Gutenberg

```bash
# Téléchargement et installation
cd /wp-content/plugins/
git clone [repository-url] tm-multi-block-plugin
```

### Installation pour Développement

```bash
# Clone du repository
git clone [repository-url] tm-multi-block-plugin
cd tm-multi-block-plugin

# Installation des dépendances
yarn install

# Build de production
yarn build

# ou Développement avec watch
yarn start
```

## 📖 Utilisation

### Ajout d'un Bloc

1. **Ouvrez** l'éditeur Gutenberg
2. **Cliquez** sur le bouton `+` pour ajouter un bloc
3. **Recherchez** "TM" ou le nom du bloc souhaité
4. **Sélectionnez** le bloc dans la liste
5. **Configurez** les paramètres dans la sidebar

### Configuration des Blocs

#### Blog Block

```
Paramètres → Paramètres du Blog
├── Nombre d'articles (1-10)
└── Afficher l'extrait (On/Off)
```

#### FAQ Block

```
Interface d'édition
├── Ajouter une question
├── Modifier Q&A existantes
└── Réorganiser les éléments
```

#### Features Block

```
Interface d'édition
├── Sélectionner une image
├── Saisir le titre
└── Ajouter la description
```

#### Table of Contents Block

```
Paramètres → Table des matières
├── Titre de la table
├── Niveaux à inclure (H1-H6)
├── Affichage (numéroté/puces)
└── Mode pliable (On/Off)
```

### Exemples d'Utilisation

#### Blog Block - Configuration Recommandée

```
✅ 3-5 articles pour la page d'accueil
✅ Extraits activés pour un aperçu complet
✅ Placement dans une section dédiée
```

#### FAQ Block - Bonnes Pratiques

```
✅ Questions courtes et claires
✅ Réponses complètes mais concises
✅ Organisation logique par thème
```

#### Features Block - Optimisation

```
✅ Images optimisées (format WebP recommandé)
✅ Textes courts et impactants
✅ Utilisation en grid pour plusieurs features
```

#### Table of Contents Block - Guide d'Utilisation

```
✅ Placer en début d'article/page
✅ H2-H3 pour articles standards
✅ H1-H4 pour pages documentation complète
✅ Mode pliable pour pages longues
```

**Cas d'Usage Recommandés :**

- 📄 **Articles de blog longs** - H2/H3 avec puces
- 📚 **Pages de documentation** - H1-H4 numérotée
- 📋 **Guides tutoriels** - H2-H4 pliable
- 🏠 **Pages d'accueil** - H2 uniquement

## 🔧 Développement

### Structure des Commandes

```bash
# Développement
yarn start          # Watch mode avec hot reload
yarn build          # Build de production
yarn lint:js        # Linting JavaScript
yarn lint:css       # Linting CSS/SCSS
yarn format         # Formatage automatique
yarn plugin-zip     # Création d'un zip pour distribution
```

### Workflow de Développement

```bash
# 1. Clone et setup
git clone [repo] && cd tm-multi-block-plugin
yarn install

# 2. Développement
yarn start

# 3. Tests
yarn test

# 4. Build final
yarn build
```

### Ajout d'un Nouveau Bloc

```bash
# Structure recommandée
src/blocks/nouveau-bloc/
├── block.json      # Configuration du bloc
├── index.js        # Point d'entrée éditeur
├── edit.js         # Composant d'édition
├── save.js         # Fonction de sauvegarde
├── view.js         # Composant front-end React
├── style.scss      # Styles front-end
└── editor.scss     # Styles éditeur
```

### Configuration d'un Bloc

```json
// block.json exemple
{
	"$schema": "https://schemas.wp.org/trunk/block.json",
	"apiVersion": 3,
	"name": "tm-multi-block/nouveau-bloc",
	"title": "Nouveau Bloc",
	"category": "widgets",
	"description": "Description du bloc",
	"supports": {
		"html": false,
		"anchor": true
	},
	"attributes": {
		"customAttribute": {
			"type": "string",
			"default": ""
		}
	}
}
```

## 📁 Structure du Projet

```
tm-multi-block-plugin/
├── 📁 build/                      # Fichiers compilés
│   └── 📁 blocks/                 # Blocs compilés
│       ├── 📁 blog/               # Blog block assets
│       ├── 📁 faq/                # FAQ block assets
│       └── 📁 features/           # Features block assets
├── 📁 src/                        # Code source
│   ├── 📁 assets/                 # Assets partagés
│   │   └── 📁 style/              # Styles SCSS communs
│   └── 📁 blocks/                 # Blocs source
│       ├── 📁 blog/               # Blog block
│       │   ├── 📄 block.json      # Configuration
│       │   ├── 📄 edit.js         # Composant éditeur
│       │   ├── 📄 save.js         # Fonction save
│       │   ├── 📄 view.js         # React front-end
│       │   ├── 📄 style.scss      # Styles front-end
│       │   └── 📄 editor.scss     # Styles éditeur
│       ├── 📁 faq/                # FAQ block
│       ├── 📁 features/           # Features block
│       └── 📄 index.js            # Point d'entrée global
├── 📁 tests/                      # Tests et validation
│   ├── 📄 test-excerpt-toggle.html
│   ├── 📄 test-block-selection.html
│   └── 📄 test-block-selection-improved.html
├── 📄 tm-multi-block-plugin.php   # Plugin principal PHP
├── 📄 package.json               # Dépendances et scripts
├── 📄 README.md                  # Documentation
└── 📄 *.md                       # Documentation technique
```

### Architecture Technique

#### Frontend (React)

- **React 18** avec hooks modernes
- **WordPress Element** pour la compatibilité
- **REST API** pour les données dynamiques
- **SCSS modulaire** pour les styles

#### Backend (PHP)

- **WordPress Hooks** pour l'intégration
- **Block API v3** pour les blocs
- **Autoloading** des blocs via `block.json`

#### Build System

- **Webpack 5** via `@wordpress/scripts`
- **Babel** pour la transpilation
- **PostCSS** pour les styles
- **Code splitting** automatique

## 🧪 Tests

### Tests Disponibles

Le plugin inclut une suite complète de tests pour valider les fonctionnalités :

#### Tests Front-end

```bash
# Fichiers de test inclus
tests/test-excerpt-toggle.html          # Test affichage conditionnel
tests/test-block-selection.html         # Test sélectabilité basique
tests/test-block-selection-improved.html # Test sélectabilité avancée
```

#### Tests Manuels

1. **Test d'intégration WordPress**
2. **Test des blocs dans Gutenberg**
3. **Test responsive design**
4. **Test accessibilité**

### Exécution des Tests

```bash
# Tests automatisés
open tests/test-block-selection-improved.html

# Tests en environnement WordPress
1. Activer le plugin
2. Créer une nouvelle page
3. Ajouter chaque type de bloc
4. Configurer les paramètres
5. Prévisualiser le front-end
```

### Validation

- ✅ **Sélectabilité des blocs** dans Gutenberg
- ✅ **Rendu front-end React** fonctionnel
- ✅ **Responsive design** sur tous écrans
- ✅ **Performance** optimisée
- ✅ **Accessibilité** conforme

## 🤝 Contribution

### Guidelines de Contribution

1. **Fork** le repository
2. **Créez** une branche feature (`git checkout -b feature/nouvelle-fonctionnalite`)
3. **Commitez** vos changements (`git commit -am 'Ajout nouvelle fonctionnalité'`)
4. **Push** vers la branche (`git push origin feature/nouvelle-fonctionnalite`)
5. **Créez** une Pull Request

### Standards de Code

- **ESLint** pour JavaScript
- **Stylelint** pour CSS/SCSS
- **WordPress Coding Standards** pour PHP
- **JSDoc** pour la documentation
- **Semantic versioning** pour les releases

### Tests Requis

- Tests automatisés passants
- Validation manuelle dans WordPress
- Vérification responsive
- Test accessibilité

## 📞 Support

### Obtenir de l'Aide

- 📧 **Email** : support@thatmuch.com
- 🐛 **Issues** : [GitHub Issues](repository-url/issues)
- 📖 **Documentation** : [Wiki du projet](repository-url/wiki)
- 💬 **Discussions** : [GitHub Discussions](repository-url/discussions)

### FAQ

#### Q: Le bloc n'apparaît pas dans Gutenberg

**R:** Vérifiez que le plugin est activé et que vous utilisez WordPress 6.0+.

#### Q: Les styles ne s'affichent pas correctement

**R:** Assurez-vous que les fichiers CSS sont compilés avec `yarn build`.

#### Q: Le bloc n'est pas sélectionnable

**R:** Ce problème a été résolu dans la v1.0.0. Mettez à jour le plugin.

#### Q: Les images ne se chargent pas dans Features Block

**R:** Vérifiez les permissions de la médiathèque WordPress.

## 📋 Changelog

### Version 1.0.0 (2025-07-28)

#### ✨ Nouvelles Fonctionnalités

- **Blog Block** : Affichage dynamique des articles avec React
- **FAQ Block** : Accordéon interactif entièrement fonctionnel
- **Features Block** : Bloc de mise en avant avec upload d'images
- **Interface Gutenberg** : Intégration native complète
- **React Front-end** : Rendu côté client pour tous les blocs

#### 🔧 Améliorations

- **Sélectabilité optimisée** : Blocs parfaitement sélectionnables dans l'éditeur
- **Performance** : Lazy loading et code splitting
- **Responsive Design** : Optimisation mobile complète
- **Accessibilité** : Support complet des standards WCAG

#### 🐛 Corrections

- Résolution des problèmes de sélection des blocs
- Optimisation du rendu React côté front-end
- Correction des conflits CSS
- Amélioration de la gestion d'erreurs

#### 🧪 Tests

- Suite de tests automatisés complète
- Validation des fonctionnalités principales
- Tests de régression inclus

## 📄 Licence

Ce projet est distribué sous la licence **GPL v2 or later**.

```
TM Multi-Block Plugin
Copyright (C) 2025 THATMUCH

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
```

---

## 🙏 Remerciements

- **WordPress Team** pour l'écosystème Gutenberg
- **React Team** pour la librairie React
- **Communauté Open Source** pour les outils et ressources

---

**Développé avec ❤️ par [THATMUCH](https://thatmuch.com)**

---

_Pour plus d'informations, consultez la [documentation complète](repository-url/wiki) ou contactez notre [équipe support](mailto:support@thatmuch.com)._
